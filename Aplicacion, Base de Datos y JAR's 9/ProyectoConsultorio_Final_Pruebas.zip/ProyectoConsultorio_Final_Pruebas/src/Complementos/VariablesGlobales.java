package Complementos;

import java.sql.Connection;
import JFrames.*;

public class VariablesGlobales {
    public static Connection conexion = null;
    
    // public static FrmVerCitas frm_verCitas = new FrmVerCitas();
    
    
    public static String numeroDeControl = "";
    public static int rol;
}
